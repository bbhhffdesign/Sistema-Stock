function Background (){
    return (
        <div className="background">

        </div>
    )
}

export default Background;