import { useState, useEffect } from "react";
import { db, auth } from "../firebaseConfig";
import { collection, query, onSnapshot, updateDoc, doc, setDoc } from "firebase/firestore";
import { onAuthStateChanged } from "firebase/auth";

function ListaProductos() {
  const [productos, setProductos] = useState([]);
  const [distribuidores, setDistribuidores] = useState([]);
  const [usuario, setUsuario] = useState(null);

  // Función para transformar el email en un ID válido
  const transformarEmail = (email) => {
    return email.replace(/[@.]/g, "_"); // Reemplaza "@" y "." por "_"
  };

  useEffect(() => {
    const unsubscribeAuth = onAuthStateChanged(auth, (user) => {
      if (user) {
        const userId = transformarEmail(user.email);
        setUsuario(user);
        escucharDistribuidores(userId);
        escucharProductos(userId);
      } else {
        setDistribuidores([]);
        setProductos([]);
      }
    });

    return () => unsubscribeAuth();
  }, []);

  const escucharDistribuidores = (userId) => {
    const q = query(collection(db, `stocks/${userId}/distribuidores`));
    return onSnapshot(q, (querySnapshot) => {
      const data = querySnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
      setDistribuidores(data);
    });
  };

  const escucharProductos = (userId) => {
    const q = query(collection(db, `stocks/${userId}/productos`));
    return onSnapshot(q, (querySnapshot) => {
      const data = querySnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
      setProductos(data);
    });
  };

  const modificarCantidad = async (id, nuevaCantidad) => {
    if (nuevaCantidad < 0 || !Number.isInteger(nuevaCantidad)) return;
    if (!usuario) return;

    try {
      const userId = transformarEmail(usuario.email);
      const productoRef = doc(db, `stocks/${userId}/productos`, id);
      await updateDoc(productoRef, { cantidadActual: nuevaCantidad });
    } catch (error) {
      console.error("Error al actualizar cantidad:", error);
    }
  };

  const registrarPedido = async (distribuidor, productosFaltantes) => {
    if (!usuario) return;

    const fechaActual = new Date();
    const fechaFormateada = fechaActual.toISOString().replace(/[:.]/g, "-").split("T").join("_");
    const idPedido = `${distribuidor.nombre}_${fechaFormateada}`.replace(/\s+/g, "_");

    const pedido = {
      distribuidorId: distribuidor.id,
      distribuidorNombre: distribuidor.nombre,
      fecha: fechaActual.toLocaleString(),
      productosFaltantes,
      usuarioId: usuario.uid,
    };

    try {
      const userId = transformarEmail(usuario.email);
      await setDoc(doc(db, `stocks/${userId}/pedidos`, idPedido), pedido);
      console.log("✅ Pedido guardado en Firebase con ID:", idPedido);
    } catch (error) {
      console.error("❌ Error al guardar el pedido:", error);
    }
  };

  const mostrarFaltantes = (distribuidor) => {
    const fechaActual = new Date().toLocaleString();
    const productosFaltantes = productos
      .filter((prod) => prod.distribuidorId === distribuidor.id && prod.cantidadActual < prod.cantidadDeseada)
      .map((prod) => ({
        nombre: prod.nombre,
        faltante: prod.cantidadDeseada - prod.cantidadActual,
      }));

    if (productosFaltantes.length > 0) {
      console.log(`📅 ${fechaActual}\nDistribuidor ${distribuidor.nombre}:`);
      productosFaltantes.forEach((prod) => console.log(`${prod.nombre}: ${prod.faltante}`));
      registrarPedido(distribuidor, productosFaltantes);
    } else {
      console.log(`📅 ${fechaActual}\nDistribuidor ${distribuidor.nombre}: No hay productos faltantes.`);
    }
  };

  return (
    <div>
      <h2>Lista de Productos</h2>
      {distribuidores.map((dist) => (
        <div key={dist.id}>
          <h3 style={{ backgroundColor: dist.color, padding: "10px", color: "#fff", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            {dist.nombre}
            <button onClick={() => mostrarFaltantes(dist)}>Registrar Pedido</button>
          </h3>

          <table border="1" width="100%">
            <thead>
              <tr>
                <th>Nombre</th>
                <th>Deseado</th>
                <th>Actual</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {productos
                .filter((prod) => prod.distribuidorId === dist.id)
                .map((prod) => (
                  <tr key={prod.id} style={{ backgroundColor: dist.color + "20" }}>
                    <td>{prod.nombre}</td>
                    <td>{prod.cantidadDeseada}</td>
                    <td>
                      <button onClick={() => modificarCantidad(prod.id, prod.cantidadActual - 1)}>-</button>
                      <input
                        type="number"
                        value={prod.cantidadActual}
                        onChange={(e) => modificarCantidad(prod.id, parseInt(e.target.value))}
                        min="0"
                      />
                      <button onClick={() => modificarCantidad(prod.id, prod.cantidadActual + 1)}>+</button>
                    </td>
                    <td>
                      <button onClick={() => console.log("Editar", prod.id)}>✏️</button>
                      <button onClick={() => console.log("Eliminar", prod.id)}>🗑️</button>
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      ))}
    </div>
  );
}

export default ListaProductos;
